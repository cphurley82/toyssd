/*****************************************************************************

  Licensed to Accellera Systems Initiative Inc. (Accellera) under one or
  more contributor license agreements.  See the NOTICE file distributed
  with this work for additional information regarding copyright ownership.
  Accellera licenses this file to you under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with the
  License.  You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
  implied.  See the License for the specific language governing
  permissions and limitations under the License.

 *****************************************************************************/

/*****************************************************************************

  fft.h - This is the interface file for the synchronous process "fft".

  Original Author: Rashmi Goswami, Synopsys, Inc.

 *****************************************************************************/

/*****************************************************************************

  MODIFICATION LOG - modifiers, enter your name, affiliation, date and
  changes you are making here.

      Name, Affiliation, Date:
  Description of Modification:

 *****************************************************************************/


struct fft: sc_module {
  sc_in<float> in_real;   
  sc_in<float> in_imag;   
  sc_in<bool> data_valid; 
  sc_in<bool> data_ack;   
  sc_out<float> out_real;        
  sc_out<float> out_imag;        
  sc_out<bool> data_req;         
  sc_out<bool> data_ready;       
  sc_in_clk CLK;

 
  SC_CTOR(fft)
    {
      SC_CTHREAD(entry, CLK.pos());
    }

 void entry();  
};      


